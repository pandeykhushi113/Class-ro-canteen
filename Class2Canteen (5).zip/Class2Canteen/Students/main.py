import os
import hashlib
from fastapi import FastAPI, HTTPException, Body, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime, timedelta
from sqlalchemy import create_engine, text, Row

# ==============================================================================
# --- Pydantic Models for Data Validation ---
# ==============================================================================

class User(BaseModel):
    id: int
    email: str
    role: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    shop_id: Optional[int] = None
    class Config: from_attributes = True

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    first_name: str
    last_name: str

class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None

class Shop(BaseModel):
    id: int
    name: str
    class Config: from_attributes = True

class Category(BaseModel):
    id: int
    name: str
    class Config: from_attributes = True

class Product(BaseModel):
    id: int
    name: str
    price: float
    description: Optional[str] = None
    image_url: Optional[str] = None
    category_id: int
    shop_id: int
    class Config: from_attributes = True

class ProductCreate(BaseModel):
    name: str
    price: float
    description: Optional[str] = None
    image_url: Optional[str] = None
    category_id: int
    shop_id: int

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    category_id: Optional[int] = None

class OrderItemCreate(BaseModel):
    id: int # product_id
    quantity: int

class OrderCreate(BaseModel):
    user_id: int
    shop_id: int
    total_price: float
    items: List[OrderItemCreate]

class OrderStatusUpdate(BaseModel):
    status: str

class DashboardStats(BaseModel):
    total_orders_today: int
    total_revenue_today: float
    recent_orders: List[dict]

class OrderSummary(BaseModel):
    pending: List[dict]
    ready: List[dict]
    completed: List[dict]

class ShopUpdate(BaseModel):
    name: str

# ==============================================================================
# --- FastAPI App Initialization & Middleware ---
# ==============================================================================

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==============================================================================
# --- Database Setup & Helpers ---
# ==============================================================================

def get_engine():
    """
    Creates a database engine. Connects to PostgreSQL if DATABASE_URL is set
    (for production on Render), otherwise falls back to a local SQLite file.
    """
    # Force SQLite for local development due to expired PostgreSQL
    return create_engine("sqlite:///database.db")

engine = get_engine()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def row_to_dict(row: Row):
    """Converts a SQLAlchemy Row object to a dictionary."""
    if row is None:
        return None
    return dict(row._mapping)


# ==============================================================================
# --- API Endpoints ---
# ==============================================================================

# --- User Authentication Endpoints ---

@app.post("/login", response_model=User)
def login(email: str = Body(...), password: str = Body(...)):
    with engine.connect() as conn:
        user_row = conn.execute(
            text('SELECT * FROM users WHERE email = :email AND password = :password'),
            {"email": email, "password": hash_password(password)}
        ).first()
    if not user_row:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return row_to_dict(user_row)

@app.post("/signup", status_code=201)
def signup(user_data: UserCreate):
    with engine.connect() as conn:
        with conn.begin(): # Start transaction
            existing_user = conn.execute(text('SELECT id FROM users WHERE email = :email'), {"email": user_data.email}).first()
            if existing_user:
                raise HTTPException(status_code=400, detail="An account with this email already exists.")
            
            hashed_password = hash_password(user_data.password)
            conn.execute(
                text('INSERT INTO users (email, password, first_name, last_name, role) VALUES (:email, :password, :first_name, :last_name, :role)'),
                {**user_data.dict(), "password": hashed_password, "role": "student"}
            )
    return {"message": "Account created successfully! Please log in."}

@app.put("/users/{user_id}", response_model=User)
def update_user(user_id: int, user_update: UserUpdate):
    update_data = user_update.model_dump(exclude_unset=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No update data provided")

    set_clause = ", ".join([f"{key} = :{key}" for key in update_data.keys()])
    params = {**update_data, "user_id": user_id}

    with engine.connect() as conn:
        with conn.begin():
            result = conn.execute(text(f'UPDATE users SET {set_clause} WHERE id = :user_id'), params)
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="User not found")
            updated_user_row = conn.execute(text('SELECT * FROM users WHERE id = :id'), {"id": user_id}).first()
    return row_to_dict(updated_user_row)

# --- General Data Endpoints ---

@app.get("/shops", response_model=List[Shop])
def get_shops():
    with engine.connect() as conn:
        shops = conn.execute(text('SELECT * FROM shops')).fetchall()
    return [row_to_dict(row) for row in shops]

@app.put("/shops/{shop_id}", response_model=Shop)
def update_shop(shop_id: int, shop_update: ShopUpdate):
    with engine.connect() as conn:
        with conn.begin():
            existing_shop = conn.execute(text('SELECT 1 FROM shops WHERE id = :id'), {"id": shop_id}).first()
            if not existing_shop:
                raise HTTPException(status_code=404, detail="Shop not found")
            try:
                conn.execute(text('UPDATE shops SET name = :name WHERE id = :id'), {"name": shop_update.name, "id": shop_id})
            except Exception: # Catch potential unique constraint errors
                raise HTTPException(status_code=400, detail="A shop with this name already exists.")
            updated_shop = conn.execute(text('SELECT * FROM shops WHERE id = :id'), {"id": shop_id}).first()
    return row_to_dict(updated_shop)

@app.get("/categories", response_model=List[Category])
def get_categories():
    with engine.connect() as conn:
        categories = conn.execute(text('SELECT * FROM categories')).fetchall()
    return [row_to_dict(row) for row in categories]

# --- Product Endpoints ---

@app.get("/products", response_model=List[Product])
def get_all_products(shop_id: Optional[int] = Query(None), category_id: Optional[int] = Query(None)):
    query = 'SELECT * FROM products'
    params = {}
    conditions = []
    if shop_id:
        conditions.append('shop_id = :shop_id')
        params['shop_id'] = shop_id
    if category_id:
        conditions.append('category_id = :category_id')
        params['category_id'] = category_id
    if conditions:
        query += ' WHERE ' + ' AND '.join(conditions)
    
    with engine.connect() as conn:
        products = conn.execute(text(query), params).fetchall()
    return [row_to_dict(row) for row in products]

# THIS IS THE CORRECT, FIXED ENDPOINT
@app.get("/products/shop/{shop_id}", response_model=List[Product])
def get_products_by_shop(shop_id: int):
    """Gets all products for a specific shop. This is used by the owner's product page."""
    with engine.connect() as conn:
        products = conn.execute(text('SELECT * FROM products WHERE shop_id = :shop_id'), {"shop_id": shop_id}).fetchall()
    return [row_to_dict(row) for row in products]


@app.get("/products/{product_id}", response_model=Product)
def get_product(product_id: int):
    with engine.connect() as conn:
        product = conn.execute(text('SELECT * FROM products WHERE id = :id'), {"id": product_id}).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return row_to_dict(product)

@app.post("/products", response_model=Product, status_code=201)
def create_product(product: ProductCreate):
    with engine.connect() as conn:
        with conn.begin():
            conn.execute(
                text('INSERT INTO products (name, price, description, image_url, category_id, shop_id) VALUES (:name, :price, :description, :image_url, :category_id, :shop_id)'),
                product.dict()
            )
            new_id = conn.execute(text('SELECT last_insert_rowid()')).scalar_one()
            new_product = conn.execute(text('SELECT * FROM products WHERE id = :id'), {"id": new_id}).first()
    return row_to_dict(new_product)

@app.put("/products/{product_id}", response_model=Product)
def update_product(product_id: int, product: ProductUpdate):
    update_data = product.model_dump(exclude_unset=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No update data provided")
    set_clause = ", ".join([f"{key} = :{key}" for key in update_data.keys()])
    params = {**update_data, "product_id": product_id}
    
    with engine.connect() as conn:
        with conn.begin():
            result = conn.execute(text(f'UPDATE products SET {set_clause} WHERE id = :product_id'), params)
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="Product not found")
            updated_product = conn.execute(text('SELECT * FROM products WHERE id = :id'), {"id": product_id}).first()
    return row_to_dict(updated_product)

# --- Order & Dashboard Endpoints ---

@app.post("/orders", status_code=201)
def create_order(order: OrderCreate):
    with engine.connect() as conn:
        with conn.begin():
            conn.execute(
                text('INSERT INTO orders (user_id, shop_id, total_price, status) VALUES (:user_id, :shop_id, :total_price, :status)'),
                {"user_id": order.user_id, "shop_id": order.shop_id, "total_price": order.total_price, "status": 'Pending'}
            )
            order_id = conn.execute(text('SELECT last_insert_rowid()')).scalar_one()

            items_data = []
            for item in order.items:
                product_price = conn.execute(text('SELECT price FROM products WHERE id = :id'), {"id": item.id}).scalar_one()
                items_data.append({"order_id": order_id, "product_id": item.id, "quantity": item.quantity, "price_per_item": product_price})

            if items_data:
                conn.execute(
                    text('INSERT INTO order_items (order_id, product_id, quantity, price_per_item) VALUES (:order_id, :product_id, :quantity, :price_per_item)'),
                    items_data
                )
    return {"message": "Order created successfully", "order_id": order_id}

@app.get("/orders/user/{user_id}", response_model=List[dict])
def get_user_orders(user_id: int):
    with engine.connect() as conn:
        orders_raw = conn.execute(text('''
            SELECT o.id as order_id, o.total_price, o.status, o.order_date, s.name as shop_name
            FROM orders o JOIN shops s ON o.shop_id = s.id
            WHERE o.user_id = :user_id ORDER BY o.order_date DESC
        '''), {"user_id": user_id}).fetchall()
    
    if not orders_raw: return []
    orders_map = {row.order_id: row_to_dict(row) for row in orders_raw}
    for order in orders_map.values(): order['items'] = []

    order_ids = tuple(orders_map.keys())
    if not order_ids: return list(orders_map.values())

    from sqlalchemy import bindparam

    with engine.connect() as conn:
        query = text(f'''
            SELECT oi.order_id, oi.quantity, oi.price_per_item, p.name as product_name, p.image_url
            FROM order_items oi JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id IN ({",".join(":order_ids_" + str(i) for i in range(len(order_ids)))})
        ''')
        params = {f"order_ids_{i}": oid for i, oid in enumerate(order_ids)}
        items_raw = conn.execute(query, params).fetchall()
    
    for item in items_raw:
        orders_map[item.order_id]['items'].append(row_to_dict(item))
        
    return list(orders_map.values())

@app.put("/orders/{order_id}/status")
def update_order_status(order_id: int, status_update: OrderStatusUpdate):
    with engine.connect() as conn:
        with conn.begin():
            result = conn.execute(text('UPDATE orders SET status = :status WHERE id = :id'), {"status": status_update.status, "id": order_id})
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="Order not found")
    return {"message": "Order status updated", "new_status": status_update.status}

@app.get("/dashboard/shop/{shop_id}", response_model=DashboardStats)
def get_dashboard_stats(shop_id: int):
    date_function = "CURRENT_DATE" if engine.dialect.name == "postgresql" else "DATE('now')"
    
    with engine.connect() as conn:
        stats = conn.execute(text(f"SELECT COUNT(id) as total_orders, SUM(total_price) as total_revenue FROM orders WHERE shop_id = :shop_id AND DATE(order_date) = {date_function}"), {"shop_id": shop_id}).first()
        recent_orders_raw = conn.execute(text("SELECT o.id as order_id, o.total_price, o.status, u.first_name, u.last_name FROM orders o JOIN users u ON o.user_id = u.id WHERE o.shop_id = :shop_id ORDER BY o.order_date DESC LIMIT 3"), {"shop_id": shop_id}).fetchall()
    
    recent_orders = [row_to_dict(row) for row in recent_orders_raw]
    if recent_orders:
        order_ids = tuple(o['order_id'] for o in recent_orders)
        for order in recent_orders: order['items'] = []

        if order_ids:
            with engine.connect() as conn:
                query = text(f"SELECT oi.order_id, oi.quantity, p.name as product_name, p.image_url FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id IN ({','.join(':order_ids_' + str(i) for i in range(len(order_ids)))})")
                params = {f"order_ids_{i}": oid for i, oid in enumerate(order_ids)}
                items_raw = conn.execute(query, params).fetchall()

            items_map = {oid: [] for oid in order_ids}
            for item in items_raw: items_map[item.order_id].append(row_to_dict(item))
            for order in recent_orders: order['items'] = items_map.get(order['order_id'], [])
        
    return {"total_orders_today": stats.total_orders or 0, "total_revenue_today": stats.total_revenue or 0.0, "recent_orders": recent_orders}

@app.get("/dashboard/shop/{shop_id}/weekly-summary")
def get_weekly_summary(shop_id: int):
    today = datetime.now().date()
    start_of_week = today - timedelta(days=today.weekday())
    
    query = text("""
        SELECT DATE(order_date) as order_day, SUM(total_price) as daily_revenue
        FROM orders
        WHERE shop_id = :shop_id AND DATE(order_date) >= :start_date
        GROUP BY DATE(order_date)
    """)
    with engine.connect() as conn:
        results = conn.execute(query, {"shop_id": shop_id, "start_date": start_of_week}).fetchall()

    daily_earnings = {row.order_day: row.daily_revenue for row in results}
    
    week_days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    final_summary = []
    for i in range(7):
        current_day = start_of_week + timedelta(days=i)
        final_summary.append({
            "day": week_days[i],
            "earnings": daily_earnings.get(current_day, 0.0),
            "is_today": current_day == today
        })
    return final_summary

@app.get("/orders/shop/{shop_id}/summary", response_model=OrderSummary)
def get_order_summary(shop_id: int):
    summary = {"pending": [], "ready": [], "completed": []}
    query = text("""
        SELECT o.id as order_id, o.total_price, o.status, o.order_date, u.first_name, u.last_name 
        FROM orders o JOIN users u ON o.user_id = u.id 
        WHERE o.shop_id = :shop_id 
        ORDER BY o.order_date DESC
    """)
    with engine.connect() as conn:
        all_orders_raw = conn.execute(query, {"shop_id": shop_id}).fetchall()

    if not all_orders_raw: return summary

    all_orders = [row_to_dict(o) for o in all_orders_raw]
    for order in all_orders:
        status = order['status'].lower()
        if status in summary:
            summary[status].append(order)
    
    orders_map = {o['order_id']: o for o in all_orders}
    for order in orders_map.values(): order['items'] = []
    
    order_ids = tuple(orders_map.keys())
    if not order_ids: return summary

    with engine.connect() as conn:
        query = text(f"SELECT oi.order_id, oi.quantity, p.name as product_name, p.image_url FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id IN ({','.join(':order_ids_' + str(i) for i in range(len(order_ids)))})")
        params = {f"order_ids_{i}": oid for i, oid in enumerate(order_ids)}
        items_raw = conn.execute(query, params).fetchall()

    for item in items_raw:
        if item.order_id in orders_map:
            orders_map[item.order_id]['items'].append(row_to_dict(item))

    return summary

# ==============================================================================
# --- Static Files Mount ---
# ==============================================================================

app.mount("/", StaticFiles(directory="static", html=True), name="static")
