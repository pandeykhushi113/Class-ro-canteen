import os
import hashlib
from sqlalchemy import create_engine, text

# --- Hashing Utility ---
def hash_password(password):
    """Hashes a password using SHA256."""
    return hashlib.sha256(password.encode()).hexdigest()

# --- Database Connection Logic ---
def get_engine():
    """
    Creates a database engine using SQLite for local development.
    """
    # Always use SQLite
    return create_engine("sqlite:///database.db")

# Commented out PostgreSQL connection for production use
# def get_engine():
#     """
#     Creates a database engine. Connects to PostgreSQL if DATABASE_URL is set
#     (for production on Render), otherwise falls back to a local SQLite file.
#     """
#     database_url = os.getenv("DATABASE_URL")
#     if database_url:
#         # Render provides a postgres:// URL, but SQLAlchemy needs postgresql://
#         if database_url.startswith("postgres://"):
#             database_url = database_url.replace("postgres://", "postgresql://", 1)
#         return create_engine(database_url)
#     else:
#         # Fallback to SQLite for local development
#         return create_engine("sqlite:///database.db")

# --- Table Creation and Seeding ---
def setup_database():
    """
    Connects to the database and sets up all tables and initial data.
    This script is safe to run multiple times.
    """
    engine = get_engine()
    db_type = engine.dialect.name
    print(f"Successfully connected to the database ({db_type}).")

    # Syntax for auto-incrementing primary key varies between databases
    autoincrement_pk = "SERIAL PRIMARY KEY" if db_type == "postgresql" else "INTEGER PRIMARY KEY AUTOINCREMENT"

    with engine.connect() as conn:
        # Use transactions for safety
        with conn.begin():
            print("Creating tables if they don't exist...")

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS users (
                id {autoincrement_pk},
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                first_name TEXT,
                last_name TEXT,
                shop_id INTEGER
            );
            """))

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS shops (
                id {autoincrement_pk},
                name TEXT NOT NULL UNIQUE
            );
            """))

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS categories (
                id {autoincrement_pk},
                name TEXT NOT NULL UNIQUE
            );
            """))

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS products (
                id {autoincrement_pk},
                name TEXT NOT NULL,
                price REAL NOT NULL,
                description TEXT,
                image_url TEXT,
                category_id INTEGER,
                shop_id INTEGER
            );
            """))

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS orders (
                id {autoincrement_pk},
                user_id INTEGER,
                shop_id INTEGER,
                total_price REAL,
                status TEXT DEFAULT 'Pending',
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """))

            conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS order_items (
                id {autoincrement_pk},
                order_id INTEGER,
                product_id INTEGER,
                quantity INTEGER,
                price_per_item REAL
            );
            """))
            print("Tables created successfully.")

            # --- Seeding Master Data ---
            print("Seeding master data...")
            
            # Seed Shops
            shops_to_seed = ['South Dhaba', 'Frankie Rolls', 'Gossip and Sip']
            for shop_name in shops_to_seed:
                result = conn.execute(text("SELECT id FROM shops WHERE name = :name"), {"name": shop_name}).first()
                if not result:
                    conn.execute(text("INSERT INTO shops (name) VALUES (:name)"), {"name": shop_name})

            # Seed Categories
            categories_to_seed = ['South Indian', 'Rolls & Wraps', 'Beverages', 'Chinese', 'Desserts', 'Sandwiches']
            for cat_name in categories_to_seed:
                result = conn.execute(text("SELECT id FROM categories WHERE name = :name"), {"name": cat_name}).first()
                if not result:
                    conn.execute(text("INSERT INTO categories (name) VALUES (:name)"), {"name": cat_name})

            # Seed Users
            users_to_seed = [
                ('student@example.com', hash_password('student123'), 'student', 'Janny', 'Doe', None),
                ('dhaba@example.com', hash_password('owner123'), 'owner', 'Rajesh', 'Kumar', 1),
                ('frankie@example.com', hash_password('owner123'), 'owner', 'Priya', 'Singh', 2),
                ('sip@example.com', hash_password('owner123'), 'owner', 'Amit', 'Sharma', 3)
            ]
            for email, pwd, role, fname, lname, shop_id in users_to_seed:
                result = conn.execute(text("SELECT id FROM users WHERE email = :email"), {"email": email}).first()
                if not result:
                    conn.execute(
                        text("INSERT INTO users (email, password, role, first_name, last_name, shop_id) VALUES (:email, :pwd, :role, :fname, :lname, :shop_id)"),
                        {"email": email, "pwd": pwd, "role": role, "fname": fname, "lname": lname, "shop_id": shop_id}
                    )

            # Seed Products
            products_to_seed = [
                ('Masala Dosa', 5.50, 'Classic South Indian crepe with potato filling.', '/images/veggie-burger.jpg', 1, 1),
                ('Idli Sambar', 8.00, 'Steamed rice cakes with lentil stew.', '/images/pasta.jpg', 1, 1),
                ('Veg Hakka Noodles', 6.75, 'Indo-Chinese stir-fried noodles.', '/images/stir-fry.jpg', 4, 1),
                ('Paneer Tikka Roll', 7.25, 'Grilled paneer wrapped in a soft flatbread.', '/images/salad.jpg', 2, 2),
                ('Chicken Shawarma Roll', 9.50, 'Classic Middle-Eastern style chicken wrap.', '/images/salmon.jpg', 2, 2),
                ('Veg Club Sandwich', 6.00, 'Triple-layered sandwich with fresh vegetables.', '/images/sandwich.jpg', 6, 2),
                ('Espresso', 2.50, 'A strong shot of coffee.', '/images/espresso.jpg', 3, 3),
                ('Iced Coffee', 3.50, 'Chilled coffee served over ice.', '/images/iced-coffee.jpg', 3, 3),
                ('Chocolate Brownie', 4.00, 'A rich and fudgy chocolate brownie.', '/images/cake.jpg', 5, 3)
            ]
            for name, price, desc, img, cat_id, shop_id in products_to_seed:
                result = conn.execute(text("SELECT id FROM products WHERE name = :name AND shop_id = :shop_id"), {"name": name, "shop_id": shop_id}).first()
                if not result:
                    conn.execute(
                        text("INSERT INTO products (name, price, description, image_url, category_id, shop_id) VALUES (:name, :price, :desc, :img, :cat_id, :shop_id)"),
                        {"name": name, "price": price, "desc": desc, "img": img, "cat_id": cat_id, "shop_id": shop_id}
                    )
            
            print("Master data seeded successfully.")

            # Add a sample completed order for testing history
            order_count_result = conn.execute(text("SELECT COUNT(id) FROM orders")).scalar_one_or_none()
            if order_count_result == 0:
                # Get user_id for student@example.com
                student_id = conn.execute(text("SELECT id FROM users WHERE email='student@example.com'")).scalar_one()
                # Get product_id for Masala Dosa
                dosa_product_id = conn.execute(text("SELECT id FROM products WHERE name='Masala Dosa'")).scalar_one()

                # Insert order with SQLite timestamp
                conn.execute(
                    text("INSERT INTO orders (user_id, shop_id, total_price, status, order_date) VALUES (:user_id, :shop_id, :total, :status, DATETIME('now', '-2 days'))"),
                    {"user_id": student_id, "shop_id": 1, "total": 5.50, "status": 'Completed'}
                )
                order1_id = conn.execute(text("SELECT last_insert_rowid()")).scalar_one()
                conn.execute(
                    text("INSERT INTO order_items (order_id, product_id, quantity, price_per_item) VALUES (:order_id, :prod_id, :qty, :price)"),
                    {"order_id": order1_id, "prod_id": dosa_product_id, "qty": 1, "price": 5.50}
                )
                print("Added one sample completed order for history.")

def main():
    """Main function to set up the database."""
    # We only remove the DB file if we are in a local environment
    if not os.getenv("DATABASE_URL") and os.path.exists('database.db'):
        os.remove('database.db')
        print("Removed existing local database file: database.db")
        
    setup_database()

if __name__ == '__main__':
    main()
