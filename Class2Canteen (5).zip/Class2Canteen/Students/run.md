# Run Guide for Class2Canteen

## Prerequisites
- Python 3.8+

## Steps


1. **Create and activate virtual environment**
   ```
   python -m venv venv
   venv\Scripts\activate  # Windows
   # source venv/bin/activate  # Linux/Mac
   ```

2. **Install dependencies**
   ```
   pip install -r requirements.txt
   ```

3. **Set up the database**
   ```
   python database.py
   ```

4. **Run the application**
   ```
   python main.py
   ```

5. **Access the application**
   Open browser and go to: http://localhost:8000
